from easyQuake.phasenet import predict
