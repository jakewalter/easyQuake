from easyQuake.sta_lta import trigger_p_s
