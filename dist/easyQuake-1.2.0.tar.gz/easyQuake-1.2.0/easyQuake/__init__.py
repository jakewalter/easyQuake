name='easyQuake'
from .easyQuake import *
