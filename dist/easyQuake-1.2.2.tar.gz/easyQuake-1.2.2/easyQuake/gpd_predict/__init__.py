from easyQuake.gpd_predict import gpd_predict
