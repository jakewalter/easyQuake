from easyQuake.phasenet import phasenet_predict
