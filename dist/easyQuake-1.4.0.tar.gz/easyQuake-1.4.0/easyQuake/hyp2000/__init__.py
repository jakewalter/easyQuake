from easyQuake.hyp2000 import *
